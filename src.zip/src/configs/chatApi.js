import Apis, { endpoints } from "./Apis";

// Tạo session chat mới
export const createChatSession = async () => {
  let res = await Apis.post(endpoints.chatSessions);
  return res.data; // {id, user, created_at...}
};

// Gửi câu hỏi
export const sendMessage = async (sessionId, question) => {
  let res = await Apis.post(`${endpoints.chatSessions}${sessionId}/ask/`, {
    question,
  });
  return res.data; // {session_id, answer, history}
};
