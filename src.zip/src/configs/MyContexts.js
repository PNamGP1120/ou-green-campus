import { createContext, useReducer } from "react";
import { UserReducer } from "../reducers/UserReducer";

export const MyContext = createContext();

export const MyProvider = ({ children }) => {
  const [state, dispatch] = useReducer(UserReducer, { user: null });

  return (
    <MyContext.Provider value={{ state, dispatch }}>
      {children}
    </MyContext.Provider>
  );
};
