import axios from "axios";

const BASE_URL = "http://127.0.0.1:8000/api";

export const endpoints = {
  login: "/auth/login/",
  register: "/auth/register/",
  me: "/users/me/",
  news: "/news/",
  projects: "/project-contests/",
  documents: "/documents/",
  feedback: "/feedbacks/",
  chatbot: "/chatbot/ask/",
  classify: "/ai/classify/",
  categories: "/categories/",
  tags: "/tags/",
  chatSessions: "/chat-sessions/",
};

export const authAxios = (token) =>
  axios.create({
    baseURL: BASE_URL,
    headers: { Authorization: `Bearer ${token}` },
  });

export default axios.create({
  baseURL: BASE_URL,
});
