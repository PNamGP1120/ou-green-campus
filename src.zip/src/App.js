import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import Login from "./components/Login";
import Register from "./components/Register";
import News from "./components/News";
import Projects from "./components/Projects";
import Documents from "./components/Documents";
import Chatbot from "./components/Chatbot";
import Feedback from "./components/Feedback";
import Header from "./components/layout/Header";
import Footer from "./components/layout/Footer";
import WasteClassifier from "./components/WasteClassifier";
import NewsDetail from "./components/NewsDetail";
import ProjectDetail from "./components/ProjectDetail";
import ChatWidget from "./components/ChatWidget";

function App() {
  return (
    <BrowserRouter>
      <Header />
      <main className="container mt-3">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/news" element={<News />} />
          <Route path="/news/:id" element={<NewsDetail />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/projects/:id" element={<ProjectDetail />} />
          <Route path="/documents" element={<Documents />} />
          <Route path="/chatbot" element={<Chatbot />} />
          <Route path="/feedback" element={<Feedback />} />
          <Route path="/classify" element={<WasteClassifier />} />
        </Routes>
      </main>

      <ChatWidget />
      <Footer />
    </BrowserRouter>
  );
}

export default App;
