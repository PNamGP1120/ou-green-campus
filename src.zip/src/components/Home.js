import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="home-page">
      {/* Hero Section */}
      <section
        className="hero d-flex align-items-center justify-content-center text-center text-white"
        style={{
          minHeight: "80vh",
          background: `linear-gradient(rgba(0, 128, 0, 0.5), rgba(0, 128, 0, 0.7)), 
                       url('/images/green-campus.jpg') center/cover no-repeat`,
        }}
      >
        <div>
          <h1 className="display-4 fw-bold">🌱 OU Green Campus</h1>
          <p className="lead mb-4">
            Hướng tới một môi trường xanh, sạch và bền vững cùng công nghệ.
          </p>
          <Link to="/projects" className="btn btn-success btn-lg me-3">
            Xem Dự Án
          </Link>
          <Link to="/chatbot" className="btn btn-outline-light btn-lg">
            Hỏi Chatbot
          </Link>
        </div>
      </section>

      {/* Giới thiệu */}
      <section className="py-5 bg-light">
        <div className="container text-center">
          <h2 className="fw-bold mb-3">Giới thiệu</h2>
          <p className="text-muted">
            OU Green Campus là dự án kết hợp công nghệ và giáo dục để nâng cao
            nhận thức bảo vệ môi trường. Hãy cùng tham gia vào cộng đồng xanh 🌍.
          </p>
        </div>
      </section>

      {/* Tin tức nổi bật */}
      <section className="py-5">
        <div className="container">
          <h2 className="text-success fw-bold text-center mb-4">📰 Tin tức nổi bật</h2>
          <div className="row">
            <div className="col-md-4 mb-3">
              <div className="card shadow-sm h-100">
                <img
                  src="/images/news1.jpg"
                  className="card-img-top"
                  alt="news"
                />
                <div className="card-body">
                  <h5 className="card-title">Ứng dụng AI trong phân loại rác</h5>
                  <p className="card-text text-muted">
                    Công nghệ AI giúp phân loại rác nhanh chóng, nâng cao hiệu quả xử lý.
                  </p>
                  <Link to="/news" className="btn btn-sm btn-success">
                    Đọc thêm
                  </Link>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-3">
              <div className="card shadow-sm h-100">
                <img
                  src="/images/news2.jpg"
                  className="card-img-top"
                  alt="news"
                />
                <div className="card-body">
                  <h5 className="card-title">Sinh viên trồng cây xanh</h5>
                  <p className="card-text text-muted">
                    Hoạt động trồng cây xanh lan tỏa thông điệp bảo vệ môi trường.
                  </p>
                  <Link to="/news" className="btn btn-sm btn-success">
                    Đọc thêm
                  </Link>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-3">
              <div className="card shadow-sm h-100">
                <img
                  src="/images/news3.jpg"
                  className="card-img-top"
                  alt="news"
                />
                <div className="card-body">
                  <h5 className="card-title">Phân loại rác tại nguồn</h5>
                  <p className="card-text text-muted">
                    Triển khai thí điểm phân loại rác tại nguồn tại khuôn viên trường.
                  </p>
                  <Link to="/news" className="btn btn-sm btn-success">
                    Đọc thêm
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Dự án */}
      <section className="py-5 bg-light">
        <div className="container">
          <h2 className="text-danger fw-bold text-center mb-4">🚀 Dự án nổi bật</h2>
          <div className="row text-center">
            <div className="col-md-4 mb-3">
              <div className="p-4 shadow-sm bg-white h-100 rounded">
                <h5>Tiết kiệm năng lượng</h5>
                <p className="text-muted">
                  Dự án triển khai đèn năng lượng mặt trời trong khuôn viên.
                </p>
              </div>
            </div>
            <div className="col-md-4 mb-3">
              <div className="p-4 shadow-sm bg-white h-100 rounded">
                <h5>Tái chế nhựa</h5>
                <p className="text-muted">
                  Biến chai nhựa thành vật liệu hữu ích trong trường học.
                </p>
              </div>
            </div>
            <div className="col-md-4 mb-3">
              <div className="p-4 shadow-sm bg-white h-100 rounded">
                <h5>Không rác thải</h5>
                <p className="text-muted">
                  Xây dựng mô hình "Zero Waste Campus" trong sinh hoạt hàng ngày.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AI Waste Classifier */}
      <section className="py-5 text-center">
        <div className="container">
          <h2 className="text-success fw-bold mb-3">🤖 AI Phân loại rác thải</h2>
          <p className="text-muted mb-4">
            Tải ảnh rác thải lên và nhận gợi ý xử lý thân thiện với môi trường.
          </p>
          <Link to="/classify" className="btn btn-lg btn-outline-success">
            Dùng ngay
          </Link>
        </div>
      </section>

      {/* Call to Action */}
      <section
        className="py-5 text-center text-white"
        style={{ background: "linear-gradient(90deg, #198754, #28a745)" }}
      >
        <div className="container">
          <h2 className="fw-bold mb-3">Cùng hành động vì môi trường 🌍</h2>
          <p className="mb-4">
            Tham gia các dự án, đọc tin tức và lan tỏa ý thức xanh trong cộng đồng.
          </p>
          <Link to="/register" className="btn btn-light btn-lg">
            Tham gia ngay
          </Link>
        </div>
      </section>

      {/* Partners */}
      <section className="py-5 bg-light">
        <div className="container text-center">
          <h2 className="fw-bold mb-4">🤝 Đối tác</h2>
          <div className="row justify-content-center">
            <div className="col-4 col-md-2 mb-3">
              <img src="/images/partner1.png" alt="Partner" className="img-fluid" />
            </div>
            <div className="col-4 col-md-2 mb-3">
              <img src="/images/partner2.png" alt="Partner" className="img-fluid" />
            </div>
            <div className="col-4 col-md-2 mb-3">
              <img src="/images/partner3.png" alt="Partner" className="img-fluid" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
