import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import axios, { endpoints, authAxios } from "../configs/Apis";
import { MyContext } from "../configs/MyContexts";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const { dispatch } = useContext(MyContext);
  const nav = useNavigate();

  const login = async (e) => {
    e.preventDefault();
    setError("");
    try {
      // gọi API login lấy JWT
      let res = await axios.post(endpoints.login, { username, password });
      let { access, refresh } = res.data;

      localStorage.setItem("access_token", access);
      localStorage.setItem("refresh_token", refresh);

      // lấy thông tin user
      let userRes = await authAxios(access).get(endpoints.me);

      dispatch({
        type: "login",
        payload: { ...userRes.data, access, refresh },
      });

      nav("/");
    } catch (err) {
      setError("Sai tên đăng nhập hoặc mật khẩu!");
    }
  };

  return (
    <div className="d-flex justify-content-center mt-5">
      <div className="card shadow p-4" style={{ maxWidth: "400px", width: "100%" }}>
        <h3 className="text-center text-success mb-3">Đăng nhập</h3>
        {error && <div className="alert alert-danger">{error}</div>}

        <form onSubmit={login}>
          <div className="mb-3">
            <label className="form-label">Tên đăng nhập</label>
            <input
              type="text"
              className="form-control"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Mật khẩu</label>
            <input
              type="password"
              className="form-control"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button className="btn btn-success w-100">Đăng nhập</button>
        </form>
      </div>
    </div>
  );
};

export default Login;
