import { useEffect, useState } from "react";
import { createChatSession, sendMessage } from "../configs/chatApi";
import { Button, Form, Spinner, Card } from "react-bootstrap";

const ChatWidget = () => {
  const [session, setSession] = useState(null);
  const [messages, setMessages] = useState([]);
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false); // 🔥 mở/đóng chatbox

  useEffect(() => {
    const initSession = async () => {
      try {
        let s = await createChatSession();
        setSession(s);
      } catch (err) {
        console.error("Lỗi tạo session:", err);
      }
    };
    initSession();
  }, []);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!question.trim()) return;

    setLoading(true);

    try {
      let res = await sendMessage(session.id, question);
      setMessages(res.history);
      setQuestion("");
    } catch (err) {
      console.error("Lỗi gửi câu hỏi:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {/* Nút tròn để bật/tắt */}
      <Button
        variant="success"
        className="chat-toggle-btn rounded-circle shadow"
        onClick={() => setOpen(!open)}
      >
        {open ? <i className="bi bi-x-lg"></i> : <i className="bi bi-chat-dots"></i>}
      </Button>

      {/* Hộp chat */}
      {open && (
        <Card className="chat-box shadow-lg">
          <Card.Header className="bg-success text-white fw-bold d-flex justify-content-between align-items-center">
            🤖 Chatbot
            <Button
              size="sm"
              variant="light"
              onClick={() => setOpen(false)}
            >
              <i className="bi bi-dash"></i>
            </Button>
          </Card.Header>
          <Card.Body style={{ maxHeight: "300px", overflowY: "auto" }}>
            {messages.length === 0 && (
              <p className="text-muted">💬 Hãy đặt câu hỏi đầu tiên...</p>
            )}
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`mb-2 p-2 rounded ${
                  m.role === "user"
                    ? "bg-light text-end"
                    : "bg-success text-white"
                }`}
              >
                <small>
                  <b>{m.role === "user" ? "Bạn" : "Bot"}:</b>
                </small>
                <div>{m.content}</div>
              </div>
            ))}
          </Card.Body>
          <Card.Footer>
            <Form onSubmit={handleSend} className="d-flex">
              <Form.Control
                type="text"
                placeholder="Nhập câu hỏi..."
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
              />
              <Button
                type="submit"
                variant="success"
                className="ms-2"
                disabled={loading}
              >
                {loading ? (
                  <Spinner size="sm" animation="border" />
                ) : (
                  <i className="bi bi-send"></i>
                )}
              </Button>
            </Form>
          </Card.Footer>
        </Card>
      )}

      {/* CSS riêng cho widget */}
      <style jsx="true">{`
        .chat-toggle-btn {
          position: fixed;
          bottom: 20px;
          right: 20px;
          width: 50px;
          height: 50px;
          display: flex;
          justify-content: center;
          align-items: center;
          font-size: 20px;
          z-index: 1000;
        }

        .chat-box {
          position: fixed;
          bottom: 80px;
          right: 20px;
          width: 300px;
          z-index: 1000;
        }
      `}</style>
    </div>
  );
};

export default ChatWidget;
