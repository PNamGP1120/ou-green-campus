const Footer = () => {
  return (
    <footer className="bg-dark text-white text-center p-3 mt-4">
      <p>© 2025 OU Green Campus | Bảo vệ môi trường vì tương lai xanh 🌱</p>
    </footer>
  );
};
export default Footer;
