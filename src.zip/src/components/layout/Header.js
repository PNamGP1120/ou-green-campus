import { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { MyContext } from "../../configs/MyContexts";

const Header = () => {
  const { state, dispatch } = useContext(MyContext);
  const nav = useNavigate();

  const logout = () => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    dispatch({ type: "logout" });
    nav("/login");
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
      <div className="container">
        {/* Logo */}
        <Link className="navbar-brand fw-bold" to="/">
          🌱 OU Green Campus
        </Link>

        {/* Nút toggle mobile */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Menu */}
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto">
            <li className="nav-item">
              <Link className="nav-link" to="/news">Tin tức</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/projects">Dự án</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/documents">Tài liệu</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/chatbot">Chatbot</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/classify">Phân loại rác</Link>
            </li>
          </ul>

          {/* Auth controls */}
          <ul className="navbar-nav">
            {!state.user ? (
              <>
                <li className="nav-item">
                  <Link className="btn btn-outline-light me-2" to="/login">
                    Đăng nhập
                  </Link>
                </li>
                <li className="nav-item">
                  <Link className="btn btn-success" to="/register">
                    Đăng ký
                  </Link>
                </li>
              </>
            ) : (
              <li className="nav-item dropdown">
                <a
                  className="nav-link dropdown-toggle d-flex align-items-center"
                  href="#!"
                  id="userDropdown"
                  role="button"
                  data-bs-toggle="dropdown"
                >
                  {/* Avatar nếu có */}
                  {state.user.avatar ? (
                    <img
                      src={state.user.avatar}
                      alt="avatar"
                      className="rounded-circle me-2"
                      width="32"
                      height="32"
                      style={{ objectFit: "cover" }}
                    />
                  ) : (
                    <span className="me-2">👤</span>
                  )}
                  {state.user.username}
                </a>
                <ul className="dropdown-menu dropdown-menu-end shadow">
                  <li>
                    <Link className="dropdown-item" to="/profile">
                      Trang cá nhân
                    </Link>
                  </li>
                  {state.user.role === "admin" && (
                    <li>
                      <Link className="dropdown-item" to="/dashboard">
                        Bảng điều khiển
                      </Link>
                    </li>
                  )}
                  <li>
                    <hr className="dropdown-divider" />
                  </li>
                  <li>
                    <button className="dropdown-item text-danger" onClick={logout}>
                      Đăng xuất
                    </button>
                  </li>
                </ul>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Header;
